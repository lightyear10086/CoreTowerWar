package me.kiconsen.corecenterwar.Heros;

import me.kiconsen.corecenterwar.Hero;
import org.bukkit.Material;

public class shadowEye extends Hero {
    public shadowEye(){
        Name="暗影之眼";
        HeroMat= Material.ENDER_EYE;
        power=Power.Ruiner;
    }
}
